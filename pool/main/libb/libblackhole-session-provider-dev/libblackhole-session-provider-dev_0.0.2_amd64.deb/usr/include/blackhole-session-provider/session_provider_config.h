#ifndef BLACKHOLE_SESSION_PROVIDER_CONFIGURATION_DEFINITION
#define BLACKHOLE_SESSION_PROVIDER_CONFIGURATION_DEFINITION

#include <stdint.h>

// The datatype used to index client sessions
typedef uint16_t sp_session_index;

struct sp_config {
    /*
    The amount of sessions that the backend server can process simultaneously.
    This impacts the size of the io_uring queue, and the amount of the pre-allocated
    session buffers. Higher values allow for more request processing per syscall,
    but also requires more memory for the pre-allocated buffers.
    */
    sp_session_index max_sessions;
    uint16_t in_buffer_size;
    uint16_t out_buffer_size;
    unsigned int first_request_timeout_ms;
};

extern const struct sp_config sp_config_default;

#endif // BLACKHOLE_SESSION_PROVIDER_CONFIGURATION_DEFINITION
