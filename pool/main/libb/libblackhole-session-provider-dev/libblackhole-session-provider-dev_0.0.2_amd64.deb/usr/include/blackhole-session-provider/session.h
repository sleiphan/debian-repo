#ifndef BLACKHOLE_SESSION_PROVIDER_SESSION_DEFINITION
#define BLACKHOLE_SESSION_PROVIDER_SESSION_DEFINITION

#include <stdint.h>

struct session;

/**
 * Returns a pointer to the input buffer of the given session.
 * The input buffer contains the bytes received from the connected client.
 * 
 * @param session The session to get the pointer to the input buffer from.
 * @return A pointer to the first byte in the input buffer of the given session.
 */
uint8_t* session_get_input_buffer(struct session* session);

unsigned int session_get_input_buffer_size(struct session* session);

/**
 * Returns the amount of bytes received from the client.
 * This data is in the input buffer of the session.
 * 
 * @param session The session in question.
 */
unsigned int session_get_input_bytes_ready(struct session* session);



uint8_t* session_get_output_buffer(struct session* session);

unsigned int session_get_output_buffer_size(struct session* session);

/**
 * @brief Tell the session the amount of bytes to send to the client from the output buffer.
 * The area in the buffer that will be sent, starts from the beginning of the buffer,
 * and ends at the offset specified by using this function.
 * The offset will be reset to 0 after every write operation.
 * 
 * @param session The session that should send bytes from its output buffer.
 * @param output_bytes_ready The amount of bytes to send from the output buffer. 
 * This value must not exceed the size of the output buffer for the session,
 * which you can choose yourself in the configuration object submitted when creating
 * the session provider.
 * @return 0 on success, -1 if the specified byte count exceeds the output buffer's size.
 */
int session_write(struct session* session, unsigned int output_bytes_ready);


/**
 * Set the input timeout value of this session.
 * 
 * After this server responds to the client, the client that holds this session slot
 * must send some data before this time has passed. When the timeout
 * is reached and no data has been received, the client will be disconnected.
 * 
 * @param session The session to change the input timeout for.
 * @param input_timeout_ms The input timeout - in milliseconds - to assign to the given session.
 */
void session_set_input_timeout(struct session* session, unsigned int input_timeout_ms);

/// @brief Decide whether a session should keep trying to read data from the associated client.
/// If turned off (default), the session will disconnect the client after one read (and optionally, write)
/// operation on the client. If turned on, the session will continue reading from the client instead of
/// closing the connection.
/// @param session The session to keep alive or not.
/// @param value The deciding value. Any non-zero enables keep-alive. A value of 0 disables keep-alive.
void session_set_keep_alive(struct session* session, int value);

void session_set_input_streaming(struct session* session, int value);

void session_set_output_streaming(struct session* session, int value);

/// @brief Make a session fully detach from the client socket it is currently responsible for.
/// The session provider will not perform ANY further actions on the returned socket.
/// The caller will be responsible for closing the socket.
/// @param session The session that should release its socket.
/// @return The file descriptor of the released socket.
int session_release_socket(struct session* session);

#endif // BLACKHOLE_SESSION_PROVIDER_SESSION_DEFINITION
