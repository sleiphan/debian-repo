#ifndef BLACKHOLE_SESSION_PROVIDER_CONFIGURATION_DEFINITION
#define BLACKHOLE_SESSION_PROVIDER_CONFIGURATION_DEFINITION

#include <stdint.h>

// The datatype used to index client sessions
typedef uint16_t sp_session_index;

struct sp_config {
    /*
    The amount of sessions that the server can process simultaneously.
    This impacts the size of the io_uring queue, and the amount of the pre-allocated
    session buffers. Higher values allow for more request processing per syscall,
    but also requires more memory for the pre-allocated buffers.
    */
    sp_session_index max_sessions;
    unsigned int in_buffer_size;
    unsigned int out_buffer_size;

    // After establishing a connection, a client
    // must send some data before this time has passed.
    // When the timeout is reached and no data has been received,
    // the client will be disconnected and the session will reset.
    unsigned int first_request_timeout_ms;
    unsigned int drain_input_timeout_ms;
};

extern const struct sp_config sp_config_default;

#endif // BLACKHOLE_SESSION_PROVIDER_CONFIGURATION_DEFINITION
