#ifndef BLACKHOLE_SESSION_PROVIDER_DEFINITION
#define BLACKHOLE_SESSION_PROVIDER_DEFINITION

#include "blackhole-session-provider/session_provider_config.h"
#include "blackhole-session-provider/session.h"

enum sp_error {
    SP_NO_ERROR = 0,

    // This error is returned when there is a problem with the implementation
    // of this library.
    SP_IMPLEMENTATION_ERROR,

    // The submitted socket is not a listening socket.
    SP_SOCKET_NOT_LISTENING,

    // The type of the submitted socket is not supported. Supported types are SOCK_STREAM.
    SP_SOCKET_UNSUPPORTED_TYPE,
};

struct session_provider;

struct session_provider* sp_create(const char* bind_address, const uint16_t port, const struct sp_config configuration);

struct session_provider* sp_create_from_socket(int listening_socket_fd, const struct sp_config configuration);

void sp_destroy(struct session_provider* sp);

int sp_wait(struct session_provider* sp);

int sp_process_available(struct session_provider* sp);

/// @brief Returns the next session that is ready for processing.
/// 
/// Any session that is returned by this function is in a suspended state.
/// This means that the session provider will not do any further processing on
/// this session before it is handed back to the session provider. See `sp_resume_session()`
/// for details about handing back the session.
/// 
/// @param sp The session provider to get the next session from.
/// 
/// @return A pointer to the next session that is ready for processing
/// by the consuming application. Returns NULL if there are no more sessions
/// ready for processing.
struct session* sp_get_next_ready_session(struct session_provider* sp);

/// @brief Resume a session that was returned by `sp_get_next_ready_session()` through
/// the rest of its lifecycle. This function is supposed to be called once the session
/// has had its input buffer _fully_ read, and its output buffer populated.
/// A session's input buffer could be overwritten between a call to this function,
/// and until it is returned again from `sp_get_next_ready_session()`.
/// 
/// @param sp The session provider owning the session.
/// @param session The session to resume.
/// @return 0 on success, -1 if the session is not owned by the specified session provider.
int sp_resume_session(struct session_provider* sp, struct session* session);


/// @brief Return the next session in the queue of sessions that received a new
/// client connection during the last call to sp_wait() and sp_process_available().
/// 
/// The queue will reset on each call to sp_wait() and sp_process_available().
/// 
/// @param sp The session provider to get the next session from.
/// @return A pointer to the next session in the queue.
/// If the queue is empty, returns NULL and assigns ENOENT to errno.
/// If an error occurred, returns NULL and and assigns the error code to errno.
struct session* sp_get_next_newly_connected_session(struct session_provider* sp);

/// @brief Return the next session in the queue of sessions that has (or is about to) disconnect its client.
/// 
/// The queue will reset on each call to sp_wait() and sp_process_available().
/// 
/// @param sp The session provider to get the next session from.
/// @return A pointer to the next session in the queue.
/// If the queue is empty, returns NULL and assigns ENOENT to errno.
/// If an error occurred, returns NULL and and assigns the error code to errno.
struct session* sp_get_next_closing_session(struct session_provider* sp);

/// @brief Checks whether a session belongs to a specific session provider.
/// @param sp The session provider.
/// @param session The session.
/// @return 1 if the session provider owns the session. Otherwise returns 0.
int sp_owns_session(const struct session_provider* sp, const struct session* session);

/// @brief Arms the given session provider for accepting client connections and running
/// the sessions through their looping lifecycles.
/// @param sp The session provider to start.
/// @return 0 on success, -1 if the session provider is already running, and -2 if a session could not be started.
int sp_start(struct session_provider* sp);

/// @brief Returns the amount of sessions still processing clients.
/// 
/// This is a good indicator for whether the session provider can be destroyed
/// without interrupting any active sessions.
/// 
/// @param sp The session provider to check.
/// @returns The amount of sessions currently busy with processing clients.
sp_session_index sp_active_sessions_count(const struct session_provider* sp);

/// @brief Stop accepting new client sockets.
/// Any sessions currently handling a client will finish processing their
/// associated client until they gracefully disconnect.
/// 
/// @param sp The session provider to shut down.
/// @return 0 on success, -1 if a shutdown procedure is already in motion.
int sp_shutdown(struct session_provider* sp);

/// @brief Make a session provider skip the first read operation on new clients.
/// This makes the session provider hand off a session immediately after accepting a
/// new client, as opposed to waiting for the client to send some data first. This is
/// for servers that - for instance - want to write some data to a new client as
/// soon as it connects.
/// @param sp The session provider to enable/disable this feature on.
/// @param enabled Any none-zero value enabled this feature. 0 disables this feature.
void sp_set_skip_first_read(struct session_provider* sp, int enabled);

#endif // BLACKHOLE_SESSION_PROVIDER_DEFINITION